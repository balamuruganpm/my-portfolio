<?php
/**
 * Admin Module: Write & Edit Blog Article (Glassmorphic Dark Edition)
 */
$admin_current_page = 'blogs';

require_once __DIR__ . '/../../config/admin-bootstrap.php';

$edit_id = isset($_GET['edit_id']) ? (int)$_GET['edit_id'] : 0;
$editing_blog = null;
$edit_idx = -1;

if ($edit_id > 0) {
    foreach ($blogs as $idx => $b) {
        if ((int)$b['id'] === $edit_id) {
            $editing_blog = $b;
            $edit_idx = $idx;
            break;
        }
    }
}

$page_title = $editing_blog ? 'Edit Article' : 'Write New Article';
$message = '';
$message_type = 'danger';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    verifyCsrfToken();
    $action = $_POST['action'];

    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $snippet = isset($_POST['snippet']) ? trim($_POST['snippet']) : '';
    $content = isset($_POST['content']) ? trim($_POST['content']) : '';
    $category = isset($_POST['category']) ? trim($_POST['category']) : 'Blog';
    $custom_slug = isset($_POST['slug']) ? trim($_POST['slug']) : '';
    $tags_raw = isset($_POST['tags']) ? trim($_POST['tags']) : '';
    $tags = !empty($tags_raw) ? array_filter(array_map('trim', explode(',', $tags_raw))) : [];

    $seo_title = isset($_POST['seo_title']) ? trim($_POST['seo_title']) : '';
    $seo_keywords = isset($_POST['seo_keywords']) ? trim($_POST['seo_keywords']) : '';
    $seo_description = isset($_POST['seo_description']) ? trim($_POST['seo_description']) : '';

    // Job specific fields
    $company = isset($_POST['company']) ? trim($_POST['company']) : '';
    $job_location = isset($_POST['job_location']) ? trim($_POST['job_location']) : '';
    $salary = isset($_POST['salary']) ? trim($_POST['salary']) : '';
    $job_type = isset($_POST['job_type']) ? trim($_POST['job_type']) : '';
    $apply_link = isset($_POST['apply_link']) ? trim($_POST['apply_link']) : '';

    $image_path = $editing_blog['image'] ?? '';
    $pdf_path = $editing_blog['pdf'] ?? '';
    $video_path = $editing_blog['video'] ?? '';

    // Upload Handlers
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $img_dir = BASE_PATH . 'uploads/images/';
        if (!is_dir($img_dir)) mkdir($img_dir, 0755, true);
        $fn = time() . '_' . preg_replace("/[^a-zA-Z0-9.]/", "_", basename($_FILES['image']['name']));
        if (move_uploaded_file($_FILES['image']['tmp_name'], $img_dir . $fn)) {
            $image_path = 'uploads/images/' . $fn;
        }
    }

    if (isset($_FILES['pdf']) && $_FILES['pdf']['error'] === UPLOAD_ERR_OK) {
        $pdf_dir = BASE_PATH . 'uploads/pdf/';
        if (!is_dir($pdf_dir)) mkdir($pdf_dir, 0755, true);
        $fn = time() . '_' . preg_replace("/[^a-zA-Z0-9.]/", "_", basename($_FILES['pdf']['name']));
        if (move_uploaded_file($_FILES['pdf']['tmp_name'], $pdf_dir . $fn)) {
            $pdf_path = 'uploads/pdf/' . $fn;
        }
    }

    if (isset($_FILES['video']) && $_FILES['video']['error'] === UPLOAD_ERR_OK) {
        $vid_dir = BASE_PATH . 'uploads/videos/';
        if (!is_dir($vid_dir)) mkdir($vid_dir, 0755, true);
        $fn = time() . '_' . preg_replace("/[^a-zA-Z0-9.]/", "_", basename($_FILES['video']['name']));
        if (move_uploaded_file($_FILES['video']['tmp_name'], $vid_dir . $fn)) {
            $video_path = 'uploads/videos/' . $fn;
        }
    }

    if (!empty($title)) {
        // Slug resolution
        $slug = !empty($custom_slug) ? strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $custom_slug))) : strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        $slug = trim(preg_replace('/-+/', '-', $slug), '-');

        $blog_entry = [
            'id' => $editing_blog ? $editing_blog['id'] : time(),
            'title' => $title,
            'slug' => $slug,
            'category' => $category,
            'tags' => $tags,
            'snippet' => $snippet,
            'content' => $content,
            'image' => $image_path,
            'pdf' => $pdf_path,
            'video' => $video_path,
            'seo_title' => $seo_title,
            'seo_keywords' => $seo_keywords,
            'seo_description' => $seo_description,
            'company' => $company,
            'job_location' => $job_location,
            'salary' => $salary,
            'job_type' => $job_type,
            'apply_link' => $apply_link,
            'date' => $editing_blog ? $editing_blog['date'] : date('Y-m-d H:i:s'),
            'views' => $editing_blog['views'] ?? 0
        ];

        if ($action === 'add') {
            $blogs[] = $blog_entry;
            $redirect_msg = "added";
        } elseif ($action === 'edit' && $edit_idx >= 0) {
            $blogs[$edit_idx] = $blog_entry;
            $redirect_msg = "updated";
        }

        if (saveAdminBlogs($blogs)) {
            header("Location: index.php?message=" . $redirect_msg);
            exit();
        } else {
            $message = 'Failed to write blog entry to database.';
        }
    } else {
        $message = 'Article Title is required.';
    }
}

include __DIR__ . '/../../layout/header.php';
?>

<div class="mb-4 d-flex align-items-center gap-3">
    <a href="index.php" class="btn btn-admin-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i> Back
    </a>
    <div>
        <h1 class="h3 fw-bold text-white mb-1"><?php echo $editing_blog ? 'Edit Blog Article' : 'Write New Article'; ?></h1>
        <p class="text-secondary small mb-0">Compose articles with rich visual/markdown formatting, video attachments, and SEO metadata</p>
    </div>
</div>

<?php if (!empty($message)): ?>
    <div class="alert alert-danger border-0 py-3 px-4 rounded-3 small d-flex align-items-center gap-2 mb-4" style="background: var(--admin-danger-bg); color: var(--admin-danger);">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <div><?php echo e($message); ?></div>
    </div>
<?php endif; ?>

<form method="POST" action="add.php<?php echo $editing_blog ? '?edit_id=' . $edit_id : ''; ?>" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo CSRF_TOKEN; ?>">
    <input type="hidden" name="action" value="<?php echo $editing_blog ? 'edit' : 'add'; ?>">

    <div class="row g-4">
        <!-- Left: Editor & Core Body -->
        <div class="col-lg-8">
            <div class="admin-card p-4 p-md-5 mb-4">
                <div class="mb-4">
                    <label class="form-label">Article Title</label>
                    <input type="text" name="title" class="form-control" placeholder="e.g. Mastering React.js Performance" required value="<?php echo e($editing_blog['title'] ?? ''); ?>">
                </div>

                <div class="mb-4">
                    <label class="form-label">Lead Excerpt / Summary</label>
                    <textarea name="snippet" rows="3" class="form-control" placeholder="A concise 1-2 sentence lead summary..." required><?php echo e($editing_blog['snippet'] ?? ''); ?></textarea>
                </div>

                <!-- WYSIWYG Editor Container -->
                <div class="mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                        <div class="d-flex align-items-center gap-2">
                            <label class="form-label mb-0 fw-semibold text-white">Article Content</label>
                            <span class="admin-badge badge-accent-subtle" id="editor-mode-indicator">Visual Mode</span>
                        </div>
                        <div class="btn-group btn-group-sm" role="group" aria-label="Editor Mode Selection">
                            <button type="button" id="btn-visual-tab" class="btn btn-admin-primary active fw-semibold px-3"><i class="bi bi-eye-fill me-1"></i>Visual</button>
                            <button type="button" id="btn-html-tab" class="btn btn-admin-secondary fw-semibold px-3"><i class="bi bi-code-slash me-1"></i>HTML Source</button>
                        </div>
                    </div>

                    <div id="rich-editor-container">
                        <div id="editor-toolbar">
                            <button type="button" class="editor-btn" onclick="formatDoc('bold')" title="Bold"><i class="bi bi-type-bold"></i></button>
                            <button type="button" class="editor-btn" onclick="formatDoc('italic')" title="Italic"><i class="bi bi-type-italic"></i></button>
                            <button type="button" class="editor-btn" onclick="formatDoc('underline')" title="Underline"><i class="bi bi-type-underline"></i></button>
                            <button type="button" class="editor-btn" onclick="formatDoc('strikeThrough')" title="Strikethrough"><i class="bi bi-type-strikethrough"></i></button>
                            <div class="editor-divider"></div>
                            <button type="button" class="editor-btn" onclick="formatDoc('formatBlock', '<h2>')" title="H2"><i class="bi bi-type-h2"></i></button>
                            <button type="button" class="editor-btn" onclick="formatDoc('formatBlock', '<h3>')" title="H3"><i class="bi bi-type-h3"></i></button>
                            <button type="button" class="editor-btn" onclick="formatDoc('formatBlock', '<p>')" title="Paragraph"><i class="bi bi-paragraph"></i></button>
                            <div class="editor-divider"></div>
                            <button type="button" class="editor-btn" onclick="formatDoc('insertUnorderedList')" title="List"><i class="bi bi-list-ul"></i></button>
                            <button type="button" class="editor-btn" onclick="formatDoc('insertOrderedList')" title="Ordered List"><i class="bi bi-list-ol"></i></button>
                            <button type="button" class="editor-btn" onclick="formatDoc('formatBlock', '<blockquote>')" title="Quote"><i class="bi bi-quote"></i></button>
                            <button type="button" class="editor-btn" onclick="formatDoc('formatBlock', '<pre>')" title="Code"><i class="bi bi-code-square"></i></button>
                            <div class="editor-divider"></div>
                            <button type="button" class="editor-btn" onclick="insertLink()" title="Link"><i class="bi bi-link-45deg"></i></button>
                            <button type="button" class="editor-btn" onclick="insertImage()" title="Image"><i class="bi bi-image"></i></button>
                            <button type="button" class="editor-btn text-danger ms-auto" onclick="formatDoc('removeFormat')" title="Clear"><i class="bi bi-eraser"></i></button>
                        </div>

                        <div id="visual-editor" contenteditable="true"><?php echo $editing_blog['content'] ?? ''; ?></div>
                        
                        <textarea name="content" id="html-editor" style="display: none;"><?php echo e($editing_blog['content'] ?? ''); ?></textarea>
                    </div>
                </div>
            </div>

            <!-- Job Specific Fields (Conditional) -->
            <div id="fields-for-job" class="conditional-section admin-card p-4 mb-4" style="display: none;">
                <h3 class="admin-card-title mb-3"><i class="bi bi-briefcase-fill text-warning"></i> Job Coordinates</h3>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Hiring Company</label>
                        <input type="text" name="company" class="form-control" placeholder="e.g. Acme Corp" value="<?php echo e($editing_blog['company'] ?? ''); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Job Location</label>
                        <input type="text" name="job_location" class="form-control" placeholder="e.g. Remote / Coimbatore" value="<?php echo e($editing_blog['job_location'] ?? ''); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Salary Range</label>
                        <input type="text" name="salary" class="form-control" placeholder="e.g. $80k - $100k" value="<?php echo e($editing_blog['salary'] ?? ''); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Job Type</label>
                        <select name="job_type" class="form-select">
                            <option value="Full-time" <?php echo (isset($editing_blog['job_type']) && $editing_blog['job_type'] === 'Full-time') ? 'selected' : ''; ?>>Full-time</option>
                            <option value="Part-time" <?php echo (isset($editing_blog['job_type']) && $editing_blog['job_type'] === 'Part-time') ? 'selected' : ''; ?>>Part-time</option>
                            <option value="Contract" <?php echo (isset($editing_blog['job_type']) && $editing_blog['job_type'] === 'Contract') ? 'selected' : ''; ?>>Contract</option>
                            <option value="Remote" <?php echo (isset($editing_blog['job_type']) && $editing_blog['job_type'] === 'Remote') ? 'selected' : ''; ?>>Remote</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Direct Apply URL</label>
                        <input type="url" name="apply_link" class="form-control" placeholder="https://..." value="<?php echo e($editing_blog['apply_link'] ?? ''); ?>">
                    </div>
                </div>
            </div>

            <!-- SEO & Meta Card + Google Search Result Preview -->
            <div class="admin-card p-4 mb-4">
                <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                    <h3 class="admin-card-title mb-0"><i class="bi bi-search text-info"></i> SEO, GEO &amp; AEO Indexing</h3>
                    <?php if ($editing_blog && !empty($editing_blog['id'])):
                        $editShortUrl = BASE_URL . 'b/' . (int)$editing_blog['id'];
                    ?>
                        <button type="button" class="btn btn-admin-secondary btn-sm py-1 px-2" onclick="navigator.clipboard && navigator.clipboard.writeText('<?php echo e($editShortUrl); ?>').then(() => window.showToast && window.showToast('Shortlink copied!', 'success'))">
                            <i class="bi bi-link-45deg text-info"></i> Copy Shortlink (/b/<?php echo (int)$editing_blog['id']; ?>)
                        </button>
                    <?php endif; ?>
                </div>

                <!-- Live Google SERP Preview -->
                <div class="serp-preview-box mb-3">
                    <div class="serp-url" id="serp-preview-url"><?php echo e(SITE_URL); ?>blogs/<span id="serp-slug-span"><?php echo e($editing_blog['slug'] ?? 'your-article-slug'); ?></span></div>
                    <div class="serp-title" id="serp-preview-title"><?php echo e(!empty($editing_blog['seo_title']) ? $editing_blog['seo_title'] : ($editing_blog['title'] ?? 'Article Title | Balamurugan P M')); ?></div>
                    <p class="serp-desc" id="serp-preview-desc"><?php echo e(!empty($editing_blog['seo_description']) ? $editing_blog['seo_description'] : ($editing_blog['snippet'] ?? 'Concise meta description shown in Google Search results and AI Overviews...')); ?></p>
                </div>

                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label">Custom URL Slug</label>
                        <input type="text" name="slug" id="slug-input" class="form-control" value="<?php echo e($editing_blog['slug'] ?? ''); ?>">
                        <span id="slug-preview" class="text-secondary small font-monospace d-block mt-1">/blogs/<?php echo e($editing_blog['slug'] ?? '...'); ?></span>
                    </div>
                    <div class="col-12">
                        <label class="form-label">SEO Title Override (50–60 chars recommended)</label>
                        <input type="text" name="seo_title" id="seo-title" class="form-control" value="<?php echo e($editing_blog['seo_title'] ?? ''); ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label">SEO / AEO Keywords (comma-separated)</label>
                        <input type="text" name="seo_keywords" class="form-control" value="<?php echo e($editing_blog['seo_keywords'] ?? ''); ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label">SEO Meta Description (140–160 chars recommended)</label>
                        <textarea name="seo_description" id="seo-description" rows="2" class="form-control"><?php echo e($editing_blog['seo_description'] ?? ''); ?></textarea>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-admin-primary px-5 py-2.5">
                <i class="bi bi-check2-circle me-1"></i> <?php echo $editing_blog ? 'Save Article Changes' : 'Publish Article'; ?>
            </button>
        </div>

        <!-- Right: Publishing Options & Media Attachments -->
        <div class="col-lg-4">
            <div class="admin-card p-4 mb-4">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <h3 class="admin-card-title mb-0"><i class="bi bi-sliders text-warning"></i> Taxonomy</h3>
                    <span id="taxonomy-badge" class="admin-badge badge-accent-subtle">Standard</span>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Category</label>
                    <?php $current_cat = $editing_blog['category'] ?? 'Blog'; ?>
                    <select name="category" id="category-select" class="form-select fw-semibold">
                        <option value="Blog" <?php echo ($current_cat === 'Blog') ? 'selected' : ''; ?>>📰 Blog Article</option>
                        <option value="Tech News" <?php echo ($current_cat === 'Tech News') ? 'selected' : ''; ?>>⚡ Tech News &amp; Updates</option>
                        <option value="React.js" <?php echo ($current_cat === 'React.js') ? 'selected' : ''; ?>>⚛️ React.js &amp; Next.js</option>
                        <option value="JavaScript" <?php echo ($current_cat === 'JavaScript') ? 'selected' : ''; ?>>🟨 Modern JavaScript</option>
                        <option value="SharePoint SPFx" <?php echo ($current_cat === 'SharePoint SPFx') ? 'selected' : ''; ?>>💼 SharePoint SPFx</option>
                        <option value="Web Performance" <?php echo ($current_cat === 'Web Performance') ? 'selected' : ''; ?>>🚀 Web Performance</option>
                        <option value="Tutorial" <?php echo ($current_cat === 'Tutorial') ? 'selected' : ''; ?>>🎓 Technical Tutorial</option>
                        <option value="Career" <?php echo ($current_cat === 'Career') ? 'selected' : ''; ?>>💡 Career &amp; Insights</option>
                        <option value="Job" <?php echo ($current_cat === 'Job') ? 'selected' : ''; ?>>💼 Job Opportunity</option>
                        <option value="custom" <?php echo (!in_array($current_cat, ['Blog', 'Tech News', 'React.js', 'JavaScript', 'SharePoint SPFx', 'Web Performance', 'Tutorial', 'Career', 'Job'])) ? 'selected' : ''; ?>>✏️ Custom Category...</option>
                    </select>
                </div>

                <div class="mb-3" id="custom-category-wrapper" style="<?php echo (!in_array($current_cat, ['Blog', 'Tech News', 'React.js', 'JavaScript', 'SharePoint SPFx', 'Web Performance', 'Tutorial', 'Career', 'Job'])) ? '' : 'display: none;'; ?>">
                    <label class="form-label">Custom Category Name</label>
                    <input type="text" name="custom_category" id="custom-category-input" class="form-control" placeholder="Enter custom category..." value="<?php echo e($current_cat); ?>">
                </div>

                <div>
                    <label class="form-label">Tags (comma-separated)</label>
                    <input type="text" name="tags" id="tags-input" class="form-control mb-2" placeholder="React, Performance, Hooks" value="<?php echo ($editing_blog && is_array($editing_blog['tags'])) ? e(implode(', ', $editing_blog['tags'])) : ''; ?>">
                    
                    <div class="small text-secondary mb-1">Quick Tag Suggestions:</div>
                    <div class="d-flex flex-wrap gap-1" id="tag-suggestions">
                        <span class="badge bg-secondary bg-opacity-25 text-white border border-secondary border-opacity-25 cursor-pointer tag-chip" data-tag="React 19">+ React 19</span>
                        <span class="badge bg-secondary bg-opacity-25 text-white border border-secondary border-opacity-25 cursor-pointer tag-chip" data-tag="Next.js">+ Next.js</span>
                        <span class="badge bg-secondary bg-opacity-25 text-white border border-secondary border-opacity-25 cursor-pointer tag-chip" data-tag="JavaScript">+ JavaScript</span>
                        <span class="badge bg-secondary bg-opacity-25 text-white border border-secondary border-opacity-25 cursor-pointer tag-chip" data-tag="SPFx">+ SPFx</span>
                        <span class="badge bg-secondary bg-opacity-25 text-white border border-secondary border-opacity-25 cursor-pointer tag-chip" data-tag="Web Performance">+ Web Performance</span>
                        <span class="badge bg-secondary bg-opacity-25 text-white border border-secondary border-opacity-25 cursor-pointer tag-chip" data-tag="SEO News">+ SEO News</span>
                    </div>
                </div>
            </div>

            <div class="admin-card p-4 mb-4">
                <h3 class="admin-card-title mb-3"><i class="bi bi-image-fill text-warning"></i> Cover Image</h3>
                <?php if ($editing_blog && !empty($editing_blog['image'])): ?>
                    <div class="mb-3 text-center">
                        <img src="<?php echo BASE_URL . e($editing_blog['image']); ?>" alt="Cover Preview" class="rounded-3 border border-secondary border-opacity-25 w-100" style="max-height: 140px; object-fit: cover;">
                    </div>
                <?php endif; ?>
                <input type="file" name="image" class="form-control" accept="image/*">
            </div>

            <div class="admin-card p-4 mb-4">
                <h3 class="admin-card-title mb-3"><i class="bi bi-file-earmark-pdf-fill text-danger"></i> PDF Document</h3>
                <?php if ($editing_blog && !empty($editing_blog['pdf'])): ?>
                    <div class="mb-2 text-success small">
                        <i class="bi bi-check-circle-fill me-1"></i> Current document attached
                    </div>
                <?php endif; ?>
                <input type="file" name="pdf" class="form-control" accept="application/pdf">
            </div>

            <div class="admin-card p-4">
                <h3 class="admin-card-title mb-3"><i class="bi bi-play-btn-fill text-info"></i> Video Attachment</h3>
                <?php if ($editing_blog && !empty($editing_blog['video'])): ?>
                    <div class="mb-2 text-success small">
                        <i class="bi bi-check-circle-fill me-1"></i> Current video attached
                    </div>
                <?php endif; ?>
                <input type="file" name="video" class="form-control" accept="video/mp4,video/webm">
            </div>
        </div>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const categorySelect = document.getElementById('category-select');
    const customCategoryWrapper = document.getElementById('custom-category-wrapper');
    const jobFields = document.getElementById('fields-for-job');
    const taxonomyBadge = document.getElementById('taxonomy-badge');
    const tagsInput = document.getElementById('tags-input');

    function updateTaxonomyFields() {
        const cat = categorySelect.value;
        if (cat === 'custom') {
            customCategoryWrapper.style.display = 'block';
        } else {
            customCategoryWrapper.style.display = 'none';
        }

        if (cat === 'Job') {
            jobFields.style.display = 'block';
            taxonomyBadge.textContent = 'Job Opportunity';
        } else {
            jobFields.style.display = 'none';
            taxonomyBadge.textContent = cat === 'custom' ? 'Custom' : cat;
        }
    }

    if (categorySelect) {
        categorySelect.addEventListener('change', updateTaxonomyFields);
        updateTaxonomyFields();
    }

    document.querySelectorAll('.tag-chip').forEach(chip => {
        chip.addEventListener('click', function() {
            const tag = this.getAttribute('data-tag');
            let currentTags = tagsInput.value.split(',').map(t => t.trim()).filter(Boolean);
            if (!currentTags.includes(tag)) {
                currentTags.push(tag);
                tagsInput.value = currentTags.join(', ');
            }
        });
    });

    // Live Google SERP Preview sync
    const titleInput = document.querySelector('input[name="title"]');
    const snippetInput = document.querySelector('textarea[name="snippet"]');
    const slugInput = document.getElementById('slug-input');
    const seoTitleInput = document.getElementById('seo-title');
    const seoDescInput = document.getElementById('seo-description');
    const serpTitle = document.getElementById('serp-preview-title');
    const serpDesc = document.getElementById('serp-preview-desc');
    const serpSlug = document.getElementById('serp-slug-span');

    function syncSerpPreview() {
        if (serpTitle) {
            const t = (seoTitleInput && seoTitleInput.value.trim()) || (titleInput && titleInput.value.trim()) || 'Article Title';
            serpTitle.textContent = t + ' | Balamurugan P M';
        }
        if (serpDesc) {
            serpDesc.textContent = (seoDescInput && seoDescInput.value.trim()) || (snippetInput && snippetInput.value.trim()) || 'Concise meta description shown in Google Search results...';
        }
        if (serpSlug && slugInput) {
            const raw = slugInput.value.trim() || (titleInput ? titleInput.value.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') : 'your-article-slug');
            serpSlug.textContent = raw;
        }
    }
    [titleInput, snippetInput, slugInput, seoTitleInput, seoDescInput].forEach(el => {
        if (el) el.addEventListener('input', syncSerpPreview);
    });
});
</script>

<?php include __DIR__ . '/../../layout/footer.php'; ?>
