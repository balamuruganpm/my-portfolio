<?php
/**
 * SEO: Analytics Tracking Scripts (Deferred & Lazy Loaded)
 * Google Tag Manager / GA4 and PostHog Analytics
 */
?>
<!-- Defer & Lazy Load Analytics Tracking Scripts -->
<script>
(function() {
    let initialized = false;
    
    function initAnalytics() {
        if (initialized) return;
        initialized = true;
        
        // Remove tracking listeners
        window.removeEventListener('scroll', initAnalytics);
        window.removeEventListener('mousemove', initAnalytics);
        window.removeEventListener('touchstart', initAnalytics);
        
        // 1. Load Google Tag Manager
        var gtmScript = document.createElement('script');
        gtmScript.async = true;
        gtmScript.src = "https://www.googletagmanager.com/gtag/js?id=<?php echo GA_TRACKING_ID; ?>";
        document.head.appendChild(gtmScript);
        
        gtmScript.onload = function() {
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '<?php echo GA_TRACKING_ID; ?>');
        };
        
        // 2. Load PostHog
        !function(t,e){var o,n,p,r;e.__SV||(window.posthog && window.posthog.__loaded)||(window.posthog=e,e._i=[],e.init=function(i,s,a){function g(t,e){var o=e.split(".");2==o.length&&(t=t[o[0]],e=o[1]),t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}}p||((p=t.createElement("script")).type="text/javascript",p.crossOrigin="anonymous",p.async=!0,p.src=s.api_host.replace(".i.posthog.com","-assets.i.posthog.com")+"/static/array.js",p.onerror=function(){p=null},(r=t.getElementsByTagName("script")[0]).parentNode.insertBefore(p,r));var u=e;for(void 0!==a?u=e[a]=[]:a="posthog",u.people=u.people||[],u.toString=function(t){var e="posthog";return"posthog"!==a&&(e+="."+a),t||(e+=" (stub)"),e},u.people.toString=function(){return u.toString(1)+".people (stub)"},o="fo po init Fo Oo qo Zs Lo Bo Ro capture Do vo Go calculateEventProperties Vo register register_once register_for_session unregister unregister_for_session Ko Ao Zo getFeatureFlag getFeatureFlagPayload getFeatureFlagResult getAllFeatureFlags isFeatureEnabled reloadFeatureFlags updateFlags updateEarlyAccessFeatureEnrollment getEarlyAccessFeatures on onFeatureFlags onSurveysLoaded onSessionId getSurveys getActiveMatchingSurveys renderSurvey displaySurvey cancelPendingSurvey canRenderSurvey canRenderSurveyAsync Yo identify setPersonProperties unsetPersonProperties group resetGroups setPersonPropertiesForFlags resetPersonPropertiesForFlags setGroupPropertiesForFlags resetGroupPropertiesForFlags reset Xo shutdown setIdentity clearIdentity get_distinct_id getGroups get_session_id get_session_replay_url alias set_config startSessionRecording stopSessionRecording sessionRecordingStarted captureException addExceptionStep captureLog startExceptionAutocapture stopExceptionAutocapture loadToolbar get_property getSessionProperty Qo Uo createPersonProfile setInternalOrTestUser Jo Eo il opt_in_capturing opt_out_capturing has_opted_in_capturing has_opted_out_capturing get_explicit_consent_status is_capturing clear_opt_in_out_capturing Ho debug Js mn getPageViewId captureTraceFeedback captureTraceMetric Co".split(" "),n=0;n<o.length;n++)g(u,o[n]);e._i.push([i,s,a])},e.__SV=1)}(document,window.posthog||[]);
        posthog.init('<?php echo POSTHOG_API_KEY; ?>', {
            api_host: 'https://us.i.posthog.com',
            defaults: '2026-05-30',
            person_profiles: 'identified_only',
        });
    }
    
    // Load tracking tools after 3.5 seconds OR on first user gesture
    setTimeout(initAnalytics, 3500);
    window.addEventListener('scroll', initAnalytics, { passive: true });
    window.addEventListener('mousemove', initAnalytics, { passive: true });
    window.addEventListener('touchstart', initAnalytics, { passive: true });
})();
</script>
